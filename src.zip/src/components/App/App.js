import Fetch from './fetch'
function App() {
  return (
    <div className="App">
      <Fetch />
    </div>
  );
}

export default App;
