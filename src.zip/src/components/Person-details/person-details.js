import React, { Component } from 'react'
import './person-details.css'

class PersonDetails extends Component{
    render(){
        return(
            <div className="person-details card">
                <img src="" alt="" className="person-image" />
            </div>
        )
    }
}